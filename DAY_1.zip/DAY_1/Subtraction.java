public class Subtraction
{
public static void main(String[]args)
{
int a=200; //initializing the integer value in variable 'a'
int b=100; //initializing the integer value in variable 'b'

int c=a-b; //Storing subtracted value in variable 'c'

System.out.println("Subtraction Result="+ c);
}
}

