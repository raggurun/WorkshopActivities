public class Multiplication
{
public static void main(String[]args)
{
int a=30; //initializing the integer value in variable 'a'
int b=10; //initializing the integer value in variable 'b'

int c=a*b; //Storing Multiplication value in variable 'c'

System.out.println("Multiplication Result="+ c);
}
}