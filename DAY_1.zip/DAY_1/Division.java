public class Division
{
public static void main(String[]args)
{
int a=80; //initializing the integer Dividend value in variable 'a'
int b=10; //initializing the integer Divisor value in variable 'b'

int c=a/b; //Storing division result 'Quotient' value in variable 'c'

System.out.println("Division Result="+ c);
}
}