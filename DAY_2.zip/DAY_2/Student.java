public class Student {
	
	int rno;
	String name;
	String division;
	
	void display()
	{
		System.out.println("Student Rollnumber: " + rno);
		System.out.println("Student name: " + name);
		System.out.println("Student division: " + division);
		System.out.println("*********************************************");
	}

	public static void main(String[] args) {
		
		Student obj1 = new Student(); //Object 1
		Student obj2 = new Student(); //Object 2
		
		obj1.rno = 20;                                           // Object 1 rollnumber initialization
		obj1.name = "Jason Huggins";                             // Object 1 name initialization
		obj1.division = "Selenium Division";                     // Object 1 division initialization
		
		obj2.rno = 50;                                           // Object 2 rollnumber initialization
		obj2.name = "Raghuraman.G";                              // Object 2 name initialization
		obj2.division = "Computer Science Division";             // Object 2 division initialization
		
		obj1.display();                                          //Function calling through Object1
		obj2.display();                                          //Function calling through Object2
		
	}

}
